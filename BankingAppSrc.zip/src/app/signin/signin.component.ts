import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setLogin, setUser } from '../store.actions';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
})
export class SigninComponent {
  login = true;

  constructor(
    private http: HttpClient,
    private router: Router,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  switchStatus() {
    this.login = !this.login;
  }

  async signupFunc(data: any) {
    console.log(data);

    if (this.login) {
      await this.http
        .post('http://localhost:9001/auth/login', data, {
          responseType: 'text',
        })
        .subscribe(
          async (res) => {
            alert('Login Successful!!');
            this.store.dispatch(setLogin({ value: false }));

            await this.http
              .get('http://localhost:9002/accounts/get/' + data['accNo'])
              .subscribe((res) => {
                console.log(res);
                this.store.dispatch(setUser({ value: res }));
              });

            this.router.navigate(['/']);
          },
          (e: HttpErrorResponse) => {
            alert(e.error);
          }
        );
    } else {
      await this.http
        .post('http://localhost:9001/accounts/create', data, {
          responseType: 'text',
        })
        .subscribe(
          (res) => {
            alert(res);
            this.login = true;
          },
          (e: HttpErrorResponse) => {
            console.log(e);
            alert(e.error);
          }
        );
    }
  }
}
