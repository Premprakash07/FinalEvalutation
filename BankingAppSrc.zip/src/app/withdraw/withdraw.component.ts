import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css'],
})
export class WithdrawComponent {
  constructor(
    private http: HttpClient,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  accNo: any;
    warning: any;
  async withdraw(data: any) {
    await this.http
      .post(
        'http://localhost:9002/transaction/withdraw/' + this.accNo + '/' + data,
        null
      )
      .subscribe((res) => {
        // alert("Withdrawal successful")
      });
  }

  ngOnInit() {
    this.store.select('data').subscribe((data) => {
      this.accNo = data.userData['accId'];
    });
  }
}
