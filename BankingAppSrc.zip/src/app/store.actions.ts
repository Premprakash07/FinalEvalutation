import {createAction, props} from '@ngrx/store'

export const setUser = createAction('setuser', props<{value: any}>())
export const setLogin = createAction('setlogin', props<{value: boolean}>())
export const setSignup = createAction('setsignup', props<{value: boolean}>())