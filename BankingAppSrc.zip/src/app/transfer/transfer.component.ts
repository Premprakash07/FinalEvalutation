import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent {
  constructor(
    private http: HttpClient,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  accNo: any;

  async transfer(data: any) {
    await this.http
      .post(
        'http://localhost:9002/transaction/transfer/' + data['transactionType'] + '/' + this.accNo + "/" + data["to"] + "/" + data["amount"],
        null
      )
      .subscribe((res) => {
        console.log(res);
        // alert("Transfer successful")
      }, (e: HttpErrorResponse) => {alert(e.error)});
  }

  ngOnInit() {
    this.store.select('data').subscribe((data) => {
      this.accNo = data.userData['accId'];
    });
  }
}
