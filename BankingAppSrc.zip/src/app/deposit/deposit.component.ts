import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css'],
})
export class DepositComponent {
  constructor(
    private http: HttpClient,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  accNo: any;

  async deposit(data: any) {
    await this.http
      .post(
        'http://localhost:9002/transaction/deposit/' + this.accNo + '/' + data,
        null
      )
      .subscribe((res) => {
        // alert("Deposit successful")
      }, (e: HttpErrorResponse) => {alert(e.error)});
  }

  ngOnInit() {
    this.store.select('data').subscribe((data) => {
      this.accNo = data.userData['accId'];
    });
  }
}
