import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css'],
})
export class TransactionComponent {
  transactions: any;

  constructor(
    private http: HttpClient,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  async ngOnInit() {
    this.store.select('data').subscribe(async (data) => {
      await this.http
        .get(
          'http://localhost:9002/transaction/getallbyacc/' +
            data.userData['accId']
        )
        .subscribe((res) => {
          this.transactions = res;
        });
    });
  }
}
