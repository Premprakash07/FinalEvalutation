import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent {
  constructor(private route: Router) {}

  toHome() {this.route.navigate(["/"])}
  toTransaction() {this.route.navigate(["/transactions"])}
  toTransfer() {this.route.navigate(["/transfer"])}
  toDeposit() {this.route.navigate(["/deposit"])}
  toWithdraw() {this.route.navigate(["/withdraw"])}
}
