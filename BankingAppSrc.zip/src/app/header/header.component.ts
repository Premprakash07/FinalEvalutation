import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setLogin, setUser } from '../store.actions';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent {
  name: any;

  constructor(private route: Router, private store: Store<{data: {
    login: boolean;
    signup: boolean;
    userData: any;
  }}>) {}

  toHome() {this.route.navigate(["/"])}

  logout() {
    this.store.dispatch(setLogin({value: true}))
    this.store.dispatch(setUser({value: null}))
  }

  ngOnInit() {
    this.store.select("data").subscribe(data => {
      this.name = data.userData["name"];
    })
  }
}
