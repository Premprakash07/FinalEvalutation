import { Component } from '@angular/core';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {
  userData : any;
  constructor(private store: Store<{data: {
    login: boolean;
    signup: boolean;
    userData: any;
  }}>) {}

  ngOnInit() {
    this.store.select("data").subscribe(data => {
      this.userData = data.userData;
    })
  }

}
