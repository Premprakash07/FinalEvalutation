import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setUser } from '../store.actions';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  constructor(
    private http: HttpClient,
    private router: Router,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  async ngOnInit() {
    this.store.select('data').subscribe(async (data) => {
      await this.http
        .get('http://localhost:9002/accounts/get/' + data.userData['accId'])
        .subscribe((res) => {
          this.store.dispatch(setUser({ value: res }));
        });
    });
  }
}
