import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { setLogin, setSignup, setUser } from './store.actions';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'BankingApp';

  constructor(
    private http: HttpClient,
    private router: Router,
    private store: Store<{
      data: {
        login: boolean;
        signup: boolean;
        userData: any;
      };
    }>
  ) {}

  ngOnInit() {
    this.store.select('data').subscribe((data) => {
      if (data.login == true) {
        this.router.navigate(['/signin']);
      }
    });
  }
}
