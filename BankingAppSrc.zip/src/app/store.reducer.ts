import { createReducer, on } from '@ngrx/store';
import { setLogin, setSignup, setUser } from './store.actions';

export const initial = {
  login: true,
  signup: false,
  userData: {},
};

export const storeReducer = createReducer(
  initial,
  on(setLogin, (state, {value}) => {
    return { ...state, login: value };
  }),
  on(setSignup, (state, {value}) => {
    return { ...state, login: value };
  }),
  on(setUser, (state, {value}) => {
    return { ...state, userData: value };
  }),
);
