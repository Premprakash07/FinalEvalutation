package com.example.AccountsServiceApplication.services;

import com.example.AccountsServiceApplication.exception.AccountNotFound;
import com.example.AccountsServiceApplication.models.AccountInfo;
import com.example.AccountsServiceApplication.models.TransactionInfo;
import com.example.AccountsServiceApplication.repositories.AccountInfoRepo;
import com.example.AccountsServiceApplication.repositories.TransactionRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

// Service class for the transaction services
@Service
@Transactional
public class TransactionService {

//    Instance for the transaction repository
    @Autowired
    private TransactionRepo transactionRepo;

//    Instance for the account repository
    @Autowired
    private AccountInfoRepo accountRepo;

//    Instance for the account service
    @Autowired
    private AccountService accountService;

//    withdraws money from the account
    public String withdraw(int accNo, double amount) throws Exception {
        AccountInfo accountInfo = this.accountService.getAccount(accNo);
        if (accountInfo.getBalance() < amount) {
            throw new Exception("Insufficient Balance");
        } else {
            accountInfo.setBalance(accountInfo.getBalance() - amount);
            this.accountService.updateAccount(accountInfo);

            TransactionInfo transactionInfo = new TransactionInfo(amount, "withdraw", accNo, accNo);

            this.transactionRepo.save(transactionInfo);

            return "Withdrawal has been made";
        }
    }

//    deposits money into the account
    public String deposit(int accNo, double amount) throws AccountNotFound {
        AccountInfo accountInfo = this.accountService.getAccount(accNo);
        accountInfo.setBalance(accountInfo.getBalance() + amount);

        this.accountService.updateAccount(accountInfo);

        TransactionInfo transactionInfo = new TransactionInfo(amount, "deposit", accNo, accNo);

        this.transactionRepo.save(transactionInfo);

        return "Deposit made successfully";
    }


//    makes transfers between the accounts
    public String transfer(String type, double amount, int fromAcc, int toAcc) throws Exception {
        AccountInfo fromAccountInfo = this.accountService.getAccount(fromAcc);
        AccountInfo toAccountInfo = this.accountService.getAccount(toAcc);

        if (fromAccountInfo.getBalance() < amount) {
            throw new Exception("Insufficient balance");
        } else {
            fromAccountInfo.setBalance(fromAccountInfo.getBalance() - amount);
            toAccountInfo.setBalance(toAccountInfo.getBalance() + amount);

            this.accountService.updateAccount(fromAccountInfo);
            this.accountService.updateAccount(toAccountInfo);

            TransactionInfo transactionInfo = new TransactionInfo(amount, type, fromAcc, toAcc);

            this.transactionRepo.save(transactionInfo);

            return "Transfer made successfully";
        }
    }

//    get all the transaction made by the account
    public List<TransactionInfo> getAllTransactionByAccNo(int accNo) throws AccountNotFound {
        if (this.accountRepo.existsById(accNo)) {
            return this.transactionRepo.findAllByAccNo(accNo);
        } else {
            throw new AccountNotFound();
        }
    }
}
