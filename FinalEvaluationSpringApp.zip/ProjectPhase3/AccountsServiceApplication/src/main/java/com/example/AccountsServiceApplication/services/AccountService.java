package com.example.AccountsServiceApplication.services;

import com.example.AccountsServiceApplication.exception.AccountNotFound;
import com.example.AccountsServiceApplication.models.AccountInfo;
import com.example.AccountsServiceApplication.repositories.AccountInfoRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

// Account service class
@Service
@Transactional
public class AccountService {

//    Instance of account repository
    @Autowired
    private AccountInfoRepo accountRepo;

//   Adds account
    public int addAccount(AccountInfo accountInfo) {
        this.accountRepo.save(accountInfo);
        AccountInfo savedInfo = this.accountRepo.findByEmail(accountInfo.getEmail()).get();
        return savedInfo.getAccId();
    }

    //    get the account details by the account no
    public AccountInfo getAccount(int accNo) throws AccountNotFound {
        Optional<AccountInfo> accountInfo = this.accountRepo.findById(accNo);
        if (accountInfo.isPresent()) {
            return accountInfo.get();
        } else {
            throw new AccountNotFound();
        }
    }

    //    update the account details
    public String updateAccount(AccountInfo accountInfo) throws AccountNotFound {
        if (this.accountRepo.existsById(accountInfo.getAccId())) {
            this.accountRepo.save(accountInfo);
            return "Account is updated";
        }
        throw new AccountNotFound();
    }

    //    deletes the account
    public String deleteAccount(String username) throws AccountNotFound {
        if (this.accountRepo.findByEmail(username).isPresent()) {
            AccountInfo accountInfo = this.accountRepo.findByEmail(username).get();
            this.accountRepo.deleteById(accountInfo.getAccId());
            return "Account deleted";
        }
        throw new AccountNotFound();
    }

}
