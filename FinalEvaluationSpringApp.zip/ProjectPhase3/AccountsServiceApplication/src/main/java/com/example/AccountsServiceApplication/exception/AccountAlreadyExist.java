package com.example.AccountsServiceApplication.exception;

// Account already exist exception
public class AccountAlreadyExist extends Exception{
    public AccountAlreadyExist() {
        super("Account already exists");
    }
}
