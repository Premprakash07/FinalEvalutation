package com.example.AccountsServiceApplication.exception;

// Account not found exception
public class AccountNotFound extends Exception{
    public AccountNotFound() {
        super("Account not found");
    }
}
