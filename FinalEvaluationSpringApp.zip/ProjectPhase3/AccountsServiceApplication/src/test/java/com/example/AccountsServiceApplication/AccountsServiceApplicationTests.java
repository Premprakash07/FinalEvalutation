package com.example.AccountsServiceApplication;

import com.example.AccountsServiceApplication.models.AccountInfo;
import com.example.AccountsServiceApplication.repositories.AccountInfoRepo;
import com.example.AccountsServiceApplication.services.AccountService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class AccountsServiceApplicationTests {

	@MockBean
	private AccountInfoRepo accountInfoRepo;

	@Autowired
	private AccountService accountService;


	@Test
	public void testExistCustomer() {
		Mockito.when(accountInfoRepo.existsById(1)).thenReturn(true);
		boolean msg = this.accountInfoRepo.existsById(1);
		assertEquals(true,msg);
	}

	@Test
	public void testAddAccount() {
		AccountInfo accountInfo = new AccountInfo();
		accountInfo.setAccountType("saving");
		accountInfo.setAddress("pune");
		accountInfo.setBalance(100.8);
		accountInfo.setName("test");
		accountInfo.setEmail("test@gmail.com");
		accountInfo.setPhoneNo(74328443);

		Mockito.when(accountInfoRepo.save(accountInfo)).thenReturn(accountInfo);

		int id = this.accountService.addAccount(accountInfo);
		assertEquals(1001,id);
	}

}
