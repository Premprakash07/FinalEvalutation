package com.example.ApplicationClient.controller;

import com.example.ApplicationClient.configuration.JwtTokenUtil;
import com.example.ApplicationClient.model.AccountCred;
import com.example.ApplicationClient.model.AccountInfo;
import com.example.ApplicationClient.repositories.AccountCredRepo;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.HashMap;

// Class tha handles accounts controller
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/accounts")
public class AccountsController {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private AccountCredRepo accountCredRepo;

//    creates an account
    @PostMapping("/create")
    public ResponseEntity<String> createAccount(@RequestBody HashMap<String, Object> account) {
        AccountInfo accountInfo = new AccountInfo();
        accountInfo.setAccountType((String) account.get("accountType"));
        accountInfo.setAddress((String) account.get("address"));
        accountInfo.setName((String) account.get("name"));
        accountInfo.setEmail((String) account.get("email"));
        accountInfo.setPhoneNo(Long.parseLong((String) account.get("phoneNo")));

        ResponseEntity<String> res = this.restTemplate.postForEntity("http://localhost:9002/accounts/add",
                accountInfo,
                String.class);
        if (res.getStatusCode() == HttpStatus.CREATED) {
            AccountCred accountCred = new AccountCred();
            accountCred.setPassword((String) account.get("pwd"));
            accountCred.setAccNo(Integer.parseInt(res.getBody()));

            this.accountCredRepo.save(accountCred);

            return new ResponseEntity<>("Account created with no: " + res.getBody(), HttpStatus.OK);
        }
        return res;
    }

//    gets account details
    @GetMapping("/get")
    public ResponseEntity<Object> getAccountDetails(HttpSession session) {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        int accNo = Integer.parseInt(authentication.getName());

//        int accNo = Integer.parseInt(this.jwtTokenUtil.getUsernameFromToken((String) session.getAttribute("userToken")));
        return this.restTemplate.getForEntity("http://localhost:9002/accounts/get/" + accNo, Object.class);
    }

}
