package com.example.ApplicationClient.service;

import com.example.ApplicationClient.model.AccountCred;
import com.example.ApplicationClient.repositories.AccountCredRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

// JwtUserDetailsService class
@Service
public class JwtUserDetailsService implements UserDetailsService {

    @Autowired
    private AccountCredRepo accountCredRepo;

//    gets user details from db using accNo
    @Override
    public UserDetails loadUserByUsername(String accNo) throws UsernameNotFoundException {
        AccountCred accountCred = this.accountCredRepo.findByAccNo(Integer.parseInt(accNo));
        if (accountCred == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new User(Integer.toString(accountCred.getAccNo()), accountCred.getPassword(),
                new ArrayList<>());
    }
}
