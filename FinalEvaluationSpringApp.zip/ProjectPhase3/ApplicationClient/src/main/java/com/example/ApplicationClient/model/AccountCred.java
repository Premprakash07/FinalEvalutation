package com.example.ApplicationClient.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

// Entity the stores the account credentials for authentication
@Entity
@Table
public class AccountCred {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int accCredId;

    @Column(unique = true, nullable = false)
    private int accNo;

    @NotBlank(message = "Please enter a valid password")
    private String password;

    public int getAccCredId() {
        return accCredId;
    }

    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
