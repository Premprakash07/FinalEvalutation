package com.example.ApplicationClient.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

// model for account information
public class AccountInfo {
    private int accId;

    private String name;

    private String email;

    private String address;

    private String accountType = "savings";

    private LocalDateTime timeOfOpening = LocalDateTime.now();

    private long phoneNo;

    private double balance = 0;

    public int getAccId() {
        return accId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public LocalDateTime getTimeOfOpening() {
        return timeOfOpening;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
