package com.example.ApplicationClient.controller;

import com.example.ApplicationClient.configuration.JwtTokenUtil;
import com.example.ApplicationClient.model.AccountCred;
import com.example.ApplicationClient.repositories.AccountCredRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;

//// Class tha
// handles auth controller
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private AccountCredRepo accountCredRepo;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

//    logs in into the account
    @PostMapping("/login")
    public ResponseEntity<String> login(HttpSession session,
                                        @RequestBody HashMap<String, Object> accCred) {
        System.out.println(accCred);
        int accNo = Integer.parseInt((String) accCred.get("accNo"));
        String password = (String) accCred.get("password");
        AccountCred accountCred = this.accountCredRepo.findByAccNo(accNo);
        if (accountCred != null) {
            if (accountCred.getPassword().equals(password)) {


                String token = this.jwtTokenUtil.generateToken(new User(Integer.toString(accNo), password, new ArrayList<>()));

                session.setAttribute("userToken", token);

                return new ResponseEntity<String>(token ,HttpStatus.OK);
            }
            return new ResponseEntity<String>("Bad Credentials", HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<String>("user not found", HttpStatus.UNAUTHORIZED);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpSession session) {
        session.setAttribute("userToken", null);

        return new ResponseEntity<String>("Logged out", HttpStatus.OK);
    }

}
