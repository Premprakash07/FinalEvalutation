package com.example.ApplicationClient.controller;

import com.example.ApplicationClient.configuration.JwtTokenUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

// Class tha handles transaction controller
@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/transaction")
public class TransactionController {

//    Instance for restTemplate
    @Autowired
    private RestTemplate restTemplate;

//    Instance for jwt utilities
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

//    endpoint for withdrawing money
    @PostMapping("/withdraw")
    public ResponseEntity<String> withdraw(HttpSession session, @RequestBody double amount) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        int accNo = Integer.parseInt(authentication.getName());
        return this.restTemplate.postForEntity("http://localhost:9002/transaction/withdraw/" + accNo + "/" + amount,
                null, String.class);
    }

//    endpoint for depositing money
    @PostMapping("/deposit")
    public ResponseEntity<String> deposit(HttpSession session, @RequestBody double amount) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        int accNo = Integer.parseInt(authentication.getName());
        return this.restTemplate.postForEntity("http://localhost:9002/transaction/deposit/" + accNo + "/" + amount,
                null, String.class);
    }

//    gets all the transaction for my account
    @GetMapping("/getmytransaction")
    public ResponseEntity<Object> getMyTransactions(HttpSession session) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        int accNo = Integer.parseInt(authentication.getName());
        return this.restTemplate.getForEntity("http://localhost:9002/transaction/getallbyacc/" + accNo, Object.class);
    }

//    create money transfer
    @PostMapping("/transfer/{type}/{toAcc}/{amount}")
    public ResponseEntity<String> transfer(HttpSession session, @PathVariable("type") String type,
                                           @PathVariable("toAcc") int toAcc,
                                           @PathVariable("amount") double amount) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        int accNo = Integer.parseInt(authentication.getName());
        return this.restTemplate.postForEntity("http://localhost:9002/transaction/transfer/" + type + "/" + accNo +
                        "/" + toAcc + "/" + amount, null, String.class);
    }

}
