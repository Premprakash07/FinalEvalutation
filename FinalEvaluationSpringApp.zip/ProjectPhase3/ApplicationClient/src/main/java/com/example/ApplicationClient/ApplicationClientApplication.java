package com.example.ApplicationClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationClientApplication.class, args);
	}

}
